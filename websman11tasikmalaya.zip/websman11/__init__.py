"""
Package for websman11.
"""
import pymysql

pymysql.install_as_MySQLdb()
