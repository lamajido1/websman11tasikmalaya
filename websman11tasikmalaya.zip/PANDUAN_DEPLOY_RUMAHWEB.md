# PANDUAN DEPLOY KE RUMAHWEB (CPANEL)

Berikut adalah langkah-langkah untuk memindahkan website ini ke hosting cPanel (RumahWeb):

## 1. Persiapan File
1.  Pastikan semua file sudah tersimpan.
2.  File `passenger_wsgi.py` sudah dibuat (wajib untuk cPanel).
3.  Library `whitenoise` sudah ditambahkan untuk menangani file statis (CSS/JS) secara otomatis.
4.  Compress/Zip seluruh isi folder project `websman11tasikmalaya`, KECUALI folder:
    - `venv`
    - `.git` (jika ada)
    - `__pycache__`
    - `db.sqlite3` (karena kita pakai MySQL/MariaDB)

## 2. Upload ke cPanel
1.  Login ke cPanel RumahWeb.
2.  Buka **File Manager**.
3.  Buat folder baru di root (sejajar dengan public_html), misalnya `websman11_source`.
4.  Upload file zip project ke dalam folder `websman11_source`.
5.  Extract file zip tersebut.

## 3. Setup Python App
1.  Di dashboard cPanel, cari menu **Setup Python App**.
2.  Klik **Create Application**.
3.  Isi form:
    - **Python Version**: Pilih 3.13 (atau 3.9+ yang tersedia).
    - **Application root**: `websman11_source` (nama folder tempat upload tadi).
    - **Application URL**: Pilih domain utama Anda (kosongkan path untuk root domain).
    - **Application startup file**: `passenger_wsgi.py`
    - **Application Entry point**: `application`
4.  Klik **Create**.

## 4. Install Dependencies
1.  Setelah aplikasi dibuat, akan muncul perintah untuk masuk ke virtual environment di bagian atas halaman (Command for entering to virtual environment). Salin perintah itu.
2.  Buka **Terminal** di cPanel (atau pakai SSH).
3.  Paste perintah tadi untuk mengaktifkan virtual environment.
4.  Masuk ke direktori project: `cd websman11_source`
5.  Install library:
    ```bash
    pip install -r requirements.txt
    ```

## 5. Konfigurasi Database & Environment
1.  Buka **MySQL Database Wizard** di cPanel.
2.  Buat database baru (misal: `smay8199_web`).
3.  Buat user database baru (misal: `smay8199_lamajido`) dan passwordnya.
4.  Berikan hak akses (All Privileges) user ke database tersebut.
5.  Edit file `websman11/settings.py` di File Manager (jika belum sesuai):
    - Pastikan `DATABASES` menggunakan nama DB, user, dan password yang baru dibuat di cPanel.
    - Pastikan `ALLOWED_HOSTS` berisi domain Anda, misal `['smay8199.sch.id', 'www.smay8199.sch.id']`.
    - Ubah `DEBUG = False` untuk keamanan.

## 6. Finalisasi
1.  Kembali ke Terminal cPanel (pastikan venv aktif).
2.  Jalankan migrasi database:
    ```bash
    python manage.py migrate
    ```
3.  Kumpulkan file statis:
    ```bash
    python manage.py collectstatic
    ```
4.  Restart aplikasi Python di menu **Setup Python App** (klik tombol Restart).

## 7. Cek Website
Buka domain Anda. Website seharusnya sudah aktif.

## Catatan Tambahan
- **Redis**: Karena Anda menggunakan cPanel, konfigurasi Redis socket `/home/smay8199/tmp/redis.sock` yang sudah kita buat di `settings.py` akan otomatis aktif jika file socket tersebut tersedia.
- **Media Files**: Agar upload foto (guru, berita, dll) bisa diakses publik, Anda perlu membuat symlink folder media ke public_html atau mengatur alias. Namun cara termudah di awal adalah memastikan folder `media` ada di dalam folder project.
