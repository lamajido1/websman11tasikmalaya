from .models import Pengaturan

def pengaturan_sekolah(request):
    try:
        pengaturan = Pengaturan.objects.first()
    except:
        pengaturan = None
    
    return {'sekolah': pengaturan}
