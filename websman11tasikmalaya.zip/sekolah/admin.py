from django.contrib import admin
from .models import Kategori, Berita, Pengumuman, Guru, Galeri, Slider, Pengaturan

@admin.register(Pengaturan)
class PengaturanAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        # Only allow one instance
        if self.model.objects.exists():
            return False
        return True

@admin.register(Kategori)
class KategoriAdmin(admin.ModelAdmin):
    list_display = ('nama', 'slug')
    prepopulated_fields = {'slug': ('nama',)}

@admin.register(Berita)
class BeritaAdmin(admin.ModelAdmin):
    list_display = ('judul', 'kategori', 'penulis', 'tanggal_publikasi')
    search_fields = ('judul', 'konten')
    list_filter = ('kategori', 'tanggal_publikasi')
    prepopulated_fields = {'slug': ('judul',)}

@admin.register(Pengumuman)
class PengumumanAdmin(admin.ModelAdmin):
    list_display = ('judul', 'tanggal')
    search_fields = ('judul',)

@admin.register(Guru)
class GuruAdmin(admin.ModelAdmin):
    list_display = ('nama', 'nip', 'mata_pelajaran')
    search_fields = ('nama', 'nip', 'mata_pelajaran')

@admin.register(Galeri)
class GaleriAdmin(admin.ModelAdmin):
    list_display = ('judul', 'tanggal')

@admin.register(Slider)
class SliderAdmin(admin.ModelAdmin):
    list_display = ('judul', 'urutan', 'aktif')
    list_editable = ('urutan', 'aktif')
    ordering = ('urutan',)
