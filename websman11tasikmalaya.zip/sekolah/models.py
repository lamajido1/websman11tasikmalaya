from django.db import models
from django.utils.text import slugify

class Kategori(models.Model):
    nama = models.CharField(max_length=100)
    slug = models.SlugField(unique=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nama)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.nama
    
    class Meta:
        verbose_name_plural = "Kategori"

class Berita(models.Model):
    judul = models.CharField(max_length=200)
    slug = models.SlugField(unique=True, blank=True)
    konten = models.TextField()
    kategori = models.ForeignKey(Kategori, on_delete=models.SET_NULL, null=True, blank=True)
    penulis = models.CharField(max_length=100)
    tanggal_publikasi = models.DateTimeField(auto_now_add=True)
    gambar = models.ImageField(upload_to='berita/', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.judul)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.judul
    
    class Meta:
        verbose_name_plural = "Berita"

class Pengumuman(models.Model):
    judul = models.CharField(max_length=200)
    isi = models.TextField()
    tanggal = models.DateField(auto_now_add=True)
    file_lampiran = models.FileField(upload_to='pengumuman/', blank=True, null=True)

    def __str__(self):
        return self.judul
    
    class Meta:
        verbose_name_plural = "Pengumuman"

class Guru(models.Model):
    nama = models.CharField(max_length=150)
    nip = models.CharField(max_length=30, blank=True, null=True)
    mata_pelajaran = models.CharField(max_length=100)
    foto = models.ImageField(upload_to='guru/', blank=True, null=True)
    bio = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.nama
    
    class Meta:
        verbose_name_plural = "Guru"

class Galeri(models.Model):
    judul = models.CharField(max_length=150)
    gambar = models.ImageField(upload_to='galeri/')
    tanggal = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.judul
    
    class Meta:
        verbose_name_plural = "Galeri"

class Slider(models.Model):
    judul = models.CharField(max_length=100)
    subjudul = models.CharField(max_length=200, blank=True, null=True)
    gambar = models.ImageField(upload_to='sliders/')
    urutan = models.IntegerField(default=0, help_text="Urutan tampilan slide (angka kecil lebih dulu)")
    aktif = models.BooleanField(default=True)
    
    def __str__(self):
        return self.judul
        
    class Meta:
        verbose_name_plural = "Slider"
        ordering = ['urutan']

class Pengaturan(models.Model):
    nama_sekolah = models.CharField(max_length=100, default='SMA Y8199 Tasikmalaya')
    slogan = models.CharField(max_length=255, blank=True, null=True, default='Mewujudkan generasi cerdas, berkarakter, dan kompetitif.')
    logo = models.ImageField(upload_to='pengaturan/', blank=True, null=True)
    favicon = models.ImageField(upload_to='pengaturan/', blank=True, null=True)
    alamat = models.TextField(blank=True, null=True)
    telepon = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    copyright = models.CharField(max_length=100, default='© 2026 Copyright SMA Y8199.')
    
    # Social Media
    facebook = models.URLField(blank=True, null=True)
    instagram = models.URLField(blank=True, null=True)
    twitter = models.URLField(blank=True, null=True)
    youtube = models.URLField(blank=True, null=True)
    
    def __str__(self):
        return self.nama_sekolah
        
    class Meta:
        verbose_name_plural = "Pengaturan Website"

